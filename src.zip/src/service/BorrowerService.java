package service;

import dao.BorrowerDAO;
import model.Borrower;
import java.util.List;
import java.util.Optional;

public class BorrowerService {
    private final BorrowerDAO borrowerDAO;

    public BorrowerService() {
        this.borrowerDAO = new BorrowerDAO();
    }

    public boolean addBorrower(Borrower borrower) {
        if (borrower == null || borrower.getMaNguoiMuon().isEmpty()) {
            return false;
        }
        if (borrowerDAO.getBorrowerById(borrower.getMaNguoiMuon()) != null) {
            System.out.println("Borrower already exists.");
            return false;
        }
        return borrowerDAO.addBorrower(borrower);
    }

    public boolean updateBorrower(Borrower borrower) {
        if (borrower == null || borrower.getMaNguoiMuon().isEmpty()) {
            return false;
        }
        return borrowerDAO.updateBorrower(borrower);
    }

    public boolean deleteBorrower(String maNguoiMuon) {
        if (maNguoiMuon == null || maNguoiMuon.isEmpty()) {
            return false;
        }
        return borrowerDAO.deleteBorrower(maNguoiMuon);
    }

    public Optional<Borrower> getBorrowerById(String maNguoiMuon) {
        return Optional.ofNullable(borrowerDAO.getBorrowerById(maNguoiMuon));
    }

    public List<Borrower> getAllBorrowers() {
        return borrowerDAO.getAllBorrowers();
    }

    public List<Borrower> searchBorrowersByName(String keyword) {
        if (keyword == null || keyword.isEmpty()) {
            return getAllBorrowers();
        }
        return borrowerDAO.getAllBorrowers().stream()
                .filter(b -> b.getTenNguoiMuon().toLowerCase().contains(keyword.toLowerCase()))
                .toList();
    }
}
