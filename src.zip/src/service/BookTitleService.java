package service;

import dao.BookTitleDAO;
import model.BookTitle;
import java.util.List;
import java.util.Optional;

public class BookTitleService {
    private final BookTitleDAO bookTitleDAO;

    public BookTitleService() {
        this.bookTitleDAO = new BookTitleDAO();
    }

    public boolean addBookTitle(BookTitle bookTitle) {
        if (bookTitle == null || bookTitle.getMaDauSach().isEmpty()) {
            return false;
        }
        if (bookTitleDAO.getBookTitleById(bookTitle.getMaDauSach()) != null) {
            System.out.println("Book title already exists.");
            return false;
        }
        return bookTitleDAO.addBookTitle(bookTitle);
    }

    public boolean updateBookTitle(BookTitle bookTitle) {
        if (bookTitle == null || bookTitle.getMaDauSach().isEmpty()) {
            return false;
        }
        return bookTitleDAO.updateBookTitle(bookTitle);
    }

    public boolean deleteBookTitle(String maDauSach) {
        if (maDauSach == null || maDauSach.isEmpty()) {
            return false;
        }
        return bookTitleDAO.deleteBookTitle(maDauSach);
    }

    public Optional<BookTitle> getBookTitleById(String maDauSach) {
        return Optional.ofNullable(bookTitleDAO.getBookTitleById(maDauSach));
    }

    public List<BookTitle> getAllBookTitles() {
        return bookTitleDAO.getAllBookTitles();
    }

    public List<BookTitle> searchBookTitles(String keyword) {
        if (keyword == null || keyword.isEmpty()) {
            return getAllBookTitles();
        }
        return getAllBookTitles().stream()
                .filter(b -> b.getTenDauSach().toLowerCase().contains(keyword.toLowerCase()))
                .toList();
    }
}
