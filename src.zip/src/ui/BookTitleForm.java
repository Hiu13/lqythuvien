package ui;

import model.BookTitle;
import service.BookTitleService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class BookTitleForm extends JFrame {
    private final BookTitleService bookTitleService;
    private JTable table;
    private DefaultTableModel model;

    private JTextField txtMaDauSach, txtTenSach, txtTacGia, txtTheLoai, txtNhaXuatBan;

    public BookTitleForm() {
        bookTitleService = new BookTitleService();
        initUI();
        loadData();
    }

    private void initUI() {
        setTitle("Quản lý Đầu sách");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Bảng
        model = new DefaultTableModel(new Object[]{"Mã", "Tên", "Tác giả", "Thể loại", "NXB"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // Form nhập liệu
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createTitledBorder("Thông tin đầu sách"));

        txtMaDauSach = new JTextField();
        txtTenSach = new JTextField();
        txtTacGia = new JTextField();
        txtTheLoai = new JTextField();
        txtNhaXuatBan = new JTextField();

        formPanel.add(new JLabel("Mã đầu sách:"));
        formPanel.add(txtMaDauSach);
        formPanel.add(new JLabel("Tên sách:"));
        formPanel.add(txtTenSach);
        formPanel.add(new JLabel("Tác giả:"));
        formPanel.add(txtTacGia);
        formPanel.add(new JLabel("Thể loại:"));
        formPanel.add(txtTheLoai);
        formPanel.add(new JLabel("Nhà xuất bản:"));
        formPanel.add(txtNhaXuatBan);

        // Nút chức năng
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton btnAdd = new JButton("Thêm");
        JButton btnUpdate = new JButton("Sửa");
        JButton btnDelete = new JButton("Xoá");
        JButton btnRefresh = new JButton("Làm mới");

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnRefresh);

        // Gắn sự kiện
        btnAdd.addActionListener(e -> addBookTitle());
        btnUpdate.addActionListener(e -> updateBookTitle());
        btnDelete.addActionListener(e -> deleteBookTitle());
        btnRefresh.addActionListener(e -> loadData());
        table.getSelectionModel().addListSelectionListener(e -> loadSelectedRow());

        // Gắn vào frame
        add(formPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadData() {
        model.setRowCount(0);
        List<BookTitle> list = bookTitleService.getAllBookTitles();
        for (BookTitle b : list) {
            model.addRow(new Object[]{
                    b.getMaDauSach(),
                    b.getTenSach(),
                    b.getTacGia(),
                    b.getTheLoai(),
                    b.getNhaXuatBan()
            });
        }
    }

    private void addBookTitle() {
        BookTitle book = getInputBookTitle();
        if (bookTitleService.addBookTitle(book)) {
            JOptionPane.showMessageDialog(this, "Thêm thành công");
            loadData();
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Thêm thất bại");
        }
    }

    private void updateBookTitle() {
        BookTitle book = getInputBookTitle();
        if (bookTitleService.updateBookTitle(book)) {
            JOptionPane.showMessageDialog(this, "Cập nhật thành công");
            loadData();
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Cập nhật thất bại");
        }
    }

    private void deleteBookTitle() {
        String ma = txtMaDauSach.getText().trim();
        if (bookTitleService.deleteBookTitle(ma)) {
            JOptionPane.showMessageDialog(this, "Xoá thành công");
            loadData();
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Xoá thất bại");
        }
    }

    private void loadSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            txtMaDauSach.setText(model.getValueAt(row, 0).toString());
            txtTenSach.setText(model.getValueAt(row, 1).toString());
            txtTacGia.setText(model.getValueAt(row, 2).toString());
            txtTheLoai.setText(model.getValueAt(row, 3).toString());
            txtNhaXuatBan.setText(model.getValueAt(row, 4).toString());
        }
    }

    private void clearForm() {
        txtMaDauSach.setText("");
        txtTenSach.setText("");
        txtTacGia.setText("");
        txtTheLoai.setText("");
        txtNhaXuatBan.setText("");
    }

    private BookTitle getInputBookTitle() {
        return new BookTitle(
                txtMaDauSach.getText().trim(),
                txtTenSach.getText().trim(),
                txtTacGia.getText().trim(),
                txtTheLoai.getText().trim(),
                txtNhaXuatBan.getText().trim()
        );
    }
}
