package quanlythuvien;
import java.sql.*;
public class DatabaseConnection{
    private static final String URL = "jdbc:mysql://localhost:3307/quanlythuvien?useSSL=false";
    private static final String USER = "root";
    private static final String PASS = "";
    public static Connection getConnection() throws SQLException{
        return DriverManager.getConnection(URL, USER, PASS);
        
    }
    public static void main(String[] args) {
        try{    
            Connection conn =  DriverManager.getConnection(URL, USER, PASS);
            System.out.println("Ket noi thanh cong!");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM quanlythuvien");
            while(rs.next()){
                String name = rs.getString("username");
                String pass = rs.getString("password");
                System.out.println(name + " | "+pass);
            }
            conn.close();
        }catch(SQLException e){
            System.out.println("Loi ket noi: "+e.getMessage());
        }
    }
}
