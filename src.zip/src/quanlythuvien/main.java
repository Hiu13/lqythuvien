package quanlythuvien;
import java.sql.*;
import java.util.Scanner;

public class main{
    private static Connection conn;
    private static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        try{
            conn = DatabaseConnection.getConnection();
            while (true){
                System.out.println("\n1. Xem danh sach");
                System.out.println("2. Them");
                System.out.println("3. Sua");
                System.out.println("4. Xoa");
                System.out.println("5. thoat");
                System.out.print("Chon: ");
                int choice = scanner.nextInt();
                scanner.nextLine();
                
                if (choice == 1){
                    viewUsers();
                }else if (choice == 2){
                    addUsers();
                }else if (choice == 3){
                    updateUsers();
                 }else if (choice == 4){
                    deleteUsers();
                }else if (choice == 5){
                    break;
                }else {
                    System.out.println("Lua chon khong hop le!");
                }
    }
        } catch (SQLException e){
            System.out.println("Loi ket noi: "+e.getMessage());
        }  finally{
            try{
                if (conn != null) conn.close();
                scanner.close();
            }catch (SQLException e){
                System.out.println("Loi dong ket noi: "+e.getMessage());
            }
        } 
    }
    private static void viewUsers() throws SQLException{
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM tb_dausach");
        while (rs.next()){
            System.out.println("MaDauSach: "+rs.getString("MaDauSach") + ", TenSach: "+ rs.getString("TenSach")+", SoLuong: "+ rs.getInt("SoLuong")+", TheLoai: "+ rs.getString("TheLoai")+", TacGia: "+ rs.getString("TacGia")+", NXB: "+ rs.getString("NXB")+", NamXB: "+ rs.getInt("NamXB"));
        }
        rs.close();
        stmt.close();
        
    }
    private static void addUsers() throws SQLException{
        System.out.println("Nhap MaDauSach: ");
        String MaDauSach = scanner.nextLine();
        System.out.println("Nhap TenSach: ");
        String TenSach = scanner.nextLine();
        System.out.println("Nhap SoLuong: ");
        int SoLuong = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Nhap TheLoai: ");
        String TheLoai = scanner.nextLine();
        System.out.println("Nhap TacGia: ");
        String TacGia = scanner.nextLine();
        System.out.println("Nhap NXB: ");
        String NXB = scanner.nextLine();
        System.out.println("Nhap NamXB: ");
        int NamXB = scanner.nextInt();
        scanner.nextLine();

        
        PreparedStatement pstmt = conn.prepareStatement("INSERT INTO tb_dausach (MaDauSach, TenSach, SoLuong, TheLoai, TacGia, NXB, NamXB) VALUES (?, ?, ?, ?, ?, ?, ?)");
        pstmt.setString(1, MaDauSach);
        pstmt.setString(2, TenSach);
        pstmt.setInt(3, SoLuong);
        pstmt.setString(4, TheLoai);
        pstmt.setString(5, TacGia);
        pstmt.setString(6, NXB);
        pstmt.setInt(7, NamXB);
        pstmt.executeUpdate();
        System.out.println("Them thanh cong!");
        pstmt.close();
    }
    private static void updateUsers() throws SQLException{
        System.out.println("Nhap MaDauSach can sua: ");
        String MaDauSach = scanner.nextLine();
        PreparedStatement checkStmt = conn.prepareStatement("SELECT 1 FROM tb_dausach WHERE MaDauSach = ?");
        checkStmt.setString(1, MaDauSach);
        ResultSet rs = checkStmt.executeQuery();
        if (!rs.next()) {
        System.out.println("MaDauSach khong ton tai!");
        return;
        }
        rs.close();
        checkStmt.close();
        System.out.println("Nhap TenSach moi: ");
        String TenSach = scanner.nextLine();
        System.out.println("Nhap SoLuong moi: ");
        int SoLuong = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Nhap TheLoai moi: ");
        String TheLoai = scanner.nextLine();
        System.out.println("Nhap TacGia moi: ");
        String TacGia = scanner.nextLine();
        System.out.println("Nhap NXB moi: ");
        String NXB = scanner.nextLine();
        System.out.println("Nhap NamXB moi: ");
        int NamXB = scanner.nextInt();
        scanner.nextLine();
        PreparedStatement pstmt = conn.prepareStatement("UPDATE tb_dausach SET TenSach = ?, TheLoai = ?, TacGia = ?, NXB = ?, NamXB = ?, Soluong = ? WHERE MaDauSach = ?");
        pstmt.setString(1, TenSach);
        pstmt.setInt(2, SoLuong);
        pstmt.setString(3, TheLoai);
        pstmt.setString(4, TacGia);
        pstmt.setString(5, NXB);
        pstmt.setInt(6, NamXB);
        pstmt.setString(7, MaDauSach);
        int rows = pstmt.executeUpdate();
        System.out.println(rows > 0 ? "Sua thanh cong!" : "MaDauSach khong ton tai!");
        pstmt.close();
    }
    private static void deleteUsers() throws SQLException{
        System.out.println("Nhap MaDauSach can xoa: ");
        String MaDauSach = scanner.nextLine();
        PreparedStatement pstmt = conn.prepareStatement("DELETE FROM tb_dausach WHERE MaDauSach = ?");
        pstmt.setString(1, MaDauSach);
        int rows = pstmt.executeUpdate();
        System.out.println(rows > 0 ? "Xoa thanh cong!" : "MaDauSach khong ton tai!");
        pstmt.close();
}
}
    